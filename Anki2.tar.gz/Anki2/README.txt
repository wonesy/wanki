This folder stores all of your Anki data in a single location,
to make backups easy. To tell Anki to use a different location,
please see:

https://docs.ankiweb.net/#/files?id=startup-options